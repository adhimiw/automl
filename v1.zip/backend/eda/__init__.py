from .automated_eda import automated_eda

__all__ = ["automated_eda"]
